package Interfaces;

public interface ContohInterfaces {
    public void PrintJudul();
    public void HitungTambah();
    public void HitungKali();

}
